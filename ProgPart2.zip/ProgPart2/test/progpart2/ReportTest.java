package progpart2;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ReportTest {

    // Creating sample Report objects for testing
    Report report1 = new Report("Create Login", null, "Mike Smith", 5, "To Do");
    Report report2 = new Report("Create Add Features", null, "Edward Harrison", 8, "Doing");
    Report report3 = new Report("Create Reports", null, "Samantha Paulson", 2, "Done");
    Report report4 = new Report("Add Arrays", null, "Glenada Oberholzer", 11, "To Do");

    public ReportTest() {
        // Constructor
    }

    /**
     * Test the displayArray method of the Report class.
     * This method tests if the displayArray method correctly outputs the details
     * of all tasks in the array.
     */
    @Test
    public void testDisplayArray() {
        // Expected result string
        String expectedResults = "";

        // Constructing expected results for each report
        expectedResults += "Task Name:\t" + "Create Login";
        expectedResults += "\nTask Number:\t" + 0;
        expectedResults += "\nTask ID:\t" + "CR:0:IKE";
        expectedResults += "\nTask user:\t" + "Mike Smith";
        expectedResults += "\nTotal hours:\t" + 5.0;
        expectedResults += "\nTask Status:\t" + "To Do" + "\n\n";

        expectedResults += "Task Name:\t" + "Create Add Features";
        expectedResults += "\nTask Number:\t" + 1;
        expectedResults += "\nTask ID:\t" + "CR:1:ARD";
        expectedResults += "\nTask user:\t" + "Edward Harrison";
        expectedResults += "\nTotal hours:\t" + 8.0;
        expectedResults += "\nTask Status:\t" + "Doing" + "\n\n";

        expectedResults += "Task Name:\t" + "Create Reports";
        expectedResults += "\nTask Number:\t" + 2;
        expectedResults += "\nTask ID:\t" + "CR:2:THA";
        expectedResults += "\nTask user:\t" + "Samantha Paulson";
        expectedResults += "\nTotal hours:\t" + 2.0;
        expectedResults += "\nTask Status:\t" + "Done" + "\n\n";

        expectedResults += "Task Name:\t" + "Add Arrays";
        expectedResults += "\nTask Number:\t" + 3;
        expectedResults += "\nTask ID:\t" + "AD:3:ZER"; // Corrected ID format
        expectedResults += "\nTask user:\t" + "Glenada Oberholzer";
        expectedResults += "\nTotal hours:\t" + 11.0;
        expectedResults += "\nTask Status:\t" + "To Do" + "\n\n";

        // Actual results from displayArray method
        String actualResults = report1.displayArray();

        // Assert that expected results match the actual results
        assertEquals(expectedResults, actualResults);
    }

    /**
     * Test the displayDoneTasks method of the Report class.
     * This method tests if the displayDoneTasks method correctly outputs the details
     * of all tasks with the status "Done".
     */
    @Test
    public void testDisplayDoneTasks() {
        // Actual results from displayDoneTasks method
        String actualResults = report3.displayDoneTasks();

        // Expected result string for tasks with status "Done"
        String expectedResults = "";
        expectedResults += "Task Name:\t" + "Create Reports";
        expectedResults += "\nTask Number:\t" + 2;
        expectedResults += "\nTask ID:\t" + "CR:2:THA";
        expectedResults += "\nTask user:\t" + "Samantha Paulson";
        expectedResults += "\nTotal hours:\t" + 2.0;
        expectedResults += "\nTask Status:\t" + "Done" + "\n\n";

        // Assert that expected results match the actual results
        assertEquals(expectedResults, actualResults);
    }

    /**
     * Test the SearchTaskName method of the Report class.
     * This method tests if the SearchTaskName method correctly identifies tasks
     * with the specified task name.
     */
    @Test
    public void testSearchTaskName() {
        // Actual result from SearchTaskName method
        boolean actualResult = report1.SearchTaskName("Create Login");

        // Assert that the task name was found (true)
        assertTrue(actualResult);
    }
}
