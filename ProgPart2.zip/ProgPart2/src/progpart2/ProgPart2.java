// Katelyn Narain ST10311395 :)
package progpart2;

// Import JOptionPane for GUI dialogs
import javax.swing.JOptionPane;

public class ProgPart2 {
    private String username;
    private String password;

    // Constructor to initialize the username and password
    public ProgPart2(String username, String password) {
        this.username = username;
        this.password = password;
    }
    
    // Variable to hold the current user
    private static ProgPart2 currentUser;

    // Main method
    public static void main(String[] args) {
        // Call the methods to register and login the user
        registerUser();
        loginUser();
    }

    // Method to check if the username is valid
    public static boolean checkUserName(String username) {
        // Username must be 5 characters long and contain an underscore
        return username != null && username.length() == 5 && username.contains("_");
    }

    // Method to check if the password meets complexity requirements
    public static boolean checkPasswordComplexity(String password) {
        // Regex to ensure the password contains at least one uppercase letter, one digit, and one special character
        String regex = "^(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]+$";
        // Password must be at least 8 characters long and match the regex pattern
        return (password.length() >= 8 && password.matches(regex));
    }

    // Method to register a new user
    private static void registerUser() {
        // Prompt the user to enter a username
        String username = JOptionPane.showInputDialog("Enter username (must be 5 characters long and contain an underscore):");
        
        // Check if the username meets the requirements
        if (checkUserName(username)) {
            // Display a success message if the username is valid
            JOptionPane.showMessageDialog(null, "Username successfully captured");
        } else {
            // Display an error message if the username is invalid and restart registration
            JOptionPane.showMessageDialog(null, "Username is not correctly formatted, please ensure that your username contains an underscore and is no longer than 5 characters in length");
            main(null);
        }

        // Prompt the user to enter a password
        String password = JOptionPane.showInputDialog("Enter password (must be at least 8 characters long and contain an uppercase letter, a number, and a special character):");
        
        // Check if the password meets the requirements
        if (checkPasswordComplexity(password)) {
            // Display a success message if the password is valid
            JOptionPane.showMessageDialog(null, "Password successfully captured");
        } else {
            // Display an error message if the password is invalid and restart registration
            JOptionPane.showMessageDialog(null, "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and special character");
            main(null);
        }

        // Save the registered user in the currentUser variable
        currentUser = new ProgPart2(username, password);
        
        // Prompt the user to enter their first name
        String firstname = JOptionPane.showInputDialog("Enter developer's first name");
        
        // Prompt the user to enter their last name
        String lastname = JOptionPane.showInputDialog("Enter developer's last name");
    }

    // Method to log in an existing user
    private static void loginUser() {
        // Prompt the user to enter their username
        String usernamelogin = JOptionPane.showInputDialog("Enter username to login:");
        
        // Prompt the user to enter their password
        String passwordlogin = JOptionPane.showInputDialog("Enter password to login:");
        
        // Check if the provided username and password match the stored user's credentials
        if (currentUser != null && usernamelogin.equals(currentUser.username) && passwordlogin.equals(currentUser.password)) {
            // Display a success message if the login is successful
            JOptionPane.showMessageDialog(null, "Login successful!");
            // Welcome the user and proceed to the application
            JOptionPane.showMessageDialog(null, "Welcome to EasyKanban");
            application();
        } else {
            // Display an error message if the login fails and retry login
            JOptionPane.showMessageDialog(null, "Invalid username or password. Please try again.");
            loginUser();
        }
    }

    // Method to display the application menu
    public static void application() {
        int option = 0;
        while (option != 3) {
            // Display the menu options to the user
            String tasks = JOptionPane.showInputDialog(null, "Please select one of the following options:(enter the number of your selection)\n"
                    + "1: Add Task\n"
                    + "2: Task report\n"
                    + "3: Exit");
            option = Integer.parseInt(tasks);
           
            switch (option) {
                case 1:
                    // Prompt the user to enter the number of tasks to create
                    String taskNumber = JOptionPane.showInputDialog(null, "Please enter the number of tasks you want to make");
                    int numTask = Integer.parseInt(taskNumber);
                    // Create the specified number of tasks and display the total duration
                    double totalAmount = createTask(numTask);
                    JOptionPane.showMessageDialog(null, "Total number of hours: " + totalAmount);
                    break;
                case 2:
                    // Display the task report
                    report();
                    break;
                case 3:
                    // Exit the application
                    JOptionPane.showMessageDialog(null, "Goodbye :)");
                    System.exit(0);
                    break;
            }
        }
    }

    // Method to create tasks
    public static double createTask(int taskNumber) {
        double total = 0;
        
        for (int i = 0; i < taskNumber; i++) {
            // Prompt the user to enter task details
            String taskName = JOptionPane.showInputDialog(null, "Please enter the NAME of task " + (i + 1));
            String description = JOptionPane.showInputDialog(null, "Please enter the description of task " + (i + 1));
            String firstname = JOptionPane.showInputDialog(null, "Please enter the developer of task " + (i + 1));
            String duration = JOptionPane.showInputDialog(null, "Please enter the duration of task " + (i + 1));
            int totalDuration = Integer.parseInt(duration);
            String taskStatus = JOptionPane.showInputDialog(null, "Please select the STATUS of transactions " + (i + 1) 
                            + "\n1: To Do\n2: Done\n3: Doing");
            int status = Integer.parseInt(taskStatus);
            
            // Retrieve the status description
            String statusDescription = retrieveStatus(status);
            
            // Create a new report object with the task details
            Report report = new Report(taskName, description, firstname, totalDuration, statusDescription);
            
            // Get the task details output
            String output = report.outputDetails();
           
            // Display the task details
            JOptionPane.showMessageDialog(null, output);
            
            // Add the task duration to the total
            total += report.getTotalDuration();
        }
 
        return total;
    }

    // Method to retrieve the task status description based on the status code
    public static String retrieveStatus(int status) {
        String taskStatus = "";
        switch (status) {
            case 1:
                taskStatus = "To Do"; 
                break;
            case 2:
                taskStatus = "Done"; 
                break;
            case 3:
                taskStatus = "Doing";
                break;
        }
        return taskStatus;
    }

    // Method to display the task report menu
    public static void report() {
        String choice = JOptionPane.showInputDialog("Please select an option:"
                + "\n1. Display all Done tasks\n"
                + "2. Display Developer with longest duration\n"
                + "3. Search by task name\n"
                + "4. Search by Developer\n"
                + "5. Delete task by task name\n"
                + "6. Display all Tasks");
        int picker = Integer.parseInt(choice);
        
        Report reportTask = new Report();
        
        switch (picker) {
            case 1:
                // Display all done tasks
                reportTask.displayDoneTasks();
                break;
            case 2:
                // Display the developer with the longest task duration
                reportTask.displayLongestDuration();
                break;
            case 3:
                // Prompt the user to enter a task name to search for
                String searchTask = JOptionPane.showInputDialog("Enter task name to search by");
                reportTask.SearchTaskName(searchTask);
                break;
            case 4:
                // Prompt the user to enter a developer name to search for
                String searchName = JOptionPane.showInputDialog("Enter developer");
                reportTask.SearchFirstname(searchName);
                break;
            case 5:
                // Prompt the user to enter a task name to delete
                String removeValue = JOptionPane.showInputDialog("Enter task name to delete");
                reportTask.RemoveTask(removeValue);
                break;
            case 6:
                // Display all tasks
                reportTask.displayArray();
                break;
            default:
                throw new AssertionError();
        }
    }
}
