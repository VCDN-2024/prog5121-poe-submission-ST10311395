//katelyn Narain ST10311395 :)
package progpart2;

import javax.swing.JOptionPane;

public class Report {

    // Private attributes for the Report class
    private String Taskname;
    private String description;
    public static int taskNumber = -1; // Static variable to keep track of the number of tasks
    public String firstname;
    private double duration;
    public static double totalDuration = 0; // Static variable to keep track of the total duration of all tasks
    String taskID;
    String taskStatus;

    // Arrays to store task details
    static String[] arrFirstnames = new String[20];
    static String[] arrTasknames = new String[20];
    static String[] arrTaskIDs = new String[20];
    static double[] arrAmounts = new double[20];
    static String[] arrTaskStatus = new String[20];

    // Default constructor
    public Report() {
    }

    // Constructor to initialize a Report object with task details
    public Report(String Taskname, String description, String firstname, int duration, String taskStatus) {
        this.Taskname = Taskname;
        this.description = description;
        taskNumber++;
        this.firstname = firstname;
        this.duration = duration;
        this.taskID = createTaskID();
        this.taskStatus = taskStatus;
        totalDuration += duration;
        populateArray(); // Populate the arrays with the task details
    }

    // Method to populate arrays with task details
    public void populateArray() {
        int position = taskNumber;
        arrFirstnames[position] = firstname;
        arrTasknames[position] = Taskname;
        arrTaskIDs[position] = taskID;
        arrAmounts[position] = duration;
        arrTaskStatus[position] = taskStatus;
    }

    // Method to display all tasks in the arrays
    public String displayArray() {
        String output = "";
        for (int i = 0; i <= taskNumber; i++) {
            output += "Task Name:\t" + arrTasknames[i];
            output += "\nTask Number:\t" + i;
            output += "\nTask ID:\t" + arrTaskIDs[i];
            output += "\nTask user:\t" + arrFirstnames[i];
            output += "\nTotal hours:\t" + arrAmounts[i];
            output += "\nTask Status:\t" + arrTaskStatus[i] + "\n\n";
        }
        JOptionPane.showMessageDialog(null, output);
        return output;
    }

    // Method to display tasks with status "Done"
    public String displayDoneTasks() {
        String output = "";
        for (int i = 0; i <= taskNumber; i++) {
            if (arrTaskStatus[i].equalsIgnoreCase("Done")) {
                output += "Task Name:\t" + arrTasknames[i];
                output += "\nTask Number:\t" + i;
                output += "\nTask ID:\t" + arrTaskIDs[i];
                output += "\nDeveloper:\t" + arrFirstnames[i];
                output += "\nTotal Hours:\t" + arrAmounts[i];
                output += "\nTask Status:\t" + arrTaskStatus[i] + "\n\n";
            }
        }
        JOptionPane.showMessageDialog(null, output);
        return output;
    }

    // Method to search for a task by name
    public boolean SearchTaskName(String Taskname) {
        boolean found = false;
        for (int i = 0; i <= taskNumber; i++) {
            if (arrTasknames[i].equalsIgnoreCase(Taskname)) {
                String output = "Task Name:\t" + arrTasknames[i];
                output += "\nTask name:\t" + arrTasknames[i];
                output += "\nDeveloper :\t" + arrFirstnames[i];
                output += "\n\nTask Status:\t" + arrTaskStatus[i];
                JOptionPane.showMessageDialog(null, output);
                found = true;
            }
        }
        if (!found) {
            JOptionPane.showMessageDialog(null, "Task not found. Please try again");
        }
        return found;
    }

    // Method to display the task with the longest duration
    public boolean displayLongestDuration() {
        if (taskNumber < 0) {
            JOptionPane.showMessageDialog(null, "No tasks available.");
            return false;
        }
        int longestDurationIndex = 0;
        for (int i = 1; i <= taskNumber; i++) {
            if (arrAmounts[i] > arrAmounts[longestDurationIndex]) {
                longestDurationIndex = i;
            }
        }
        String output = "The longest duration is: " + arrAmounts[longestDurationIndex]
                + "\nDeveloper: " + arrFirstnames[longestDurationIndex];
        JOptionPane.showMessageDialog(null, output);
        return true;
    }

    // Method to search for tasks by developer's first name
    public boolean SearchFirstname(String firstname) {
        boolean found = false;
        for (int i = 0; i <= taskNumber; i++) {
            if (arrFirstnames[i].equalsIgnoreCase(firstname)) {
                String output = "Developer :\t" + arrFirstnames[i];
                output += "\nTask name:\t" + arrTasknames[i];
                output += "\n\nTask Status:\t" + arrTaskStatus[i];
                JOptionPane.showMessageDialog(null, output);
                found = true;
            }
        }
        if (!found) {
            JOptionPane.showMessageDialog(null, "Developer not found. Please try again");
        }
        return found;
    }

    // Method to remove a task by name
    public boolean RemoveTask(String Taskname) {
        String[] temparAarrFirstnames = new String[taskNumber + 1];
        String[] tempArrNames = new String[taskNumber + 1];
        String[] tempArrTaskIDs = new String[taskNumber + 1];
        double[] tempArrAmounts = new double[taskNumber + 1];
        String[] tempArrTaskStatus = new String[taskNumber + 1];
        int j = 0;
        boolean removed = false;
        for (int i = 0; i <= taskNumber; i++) {
            if (!(arrTasknames[i].equalsIgnoreCase(Taskname))) {
                tempArrAmounts[j] = arrAmounts[i];
                tempArrTaskIDs[j] = arrTaskIDs[i];
                tempArrNames[j] = arrTasknames[i];
                tempArrTaskStatus[j] = arrTaskStatus[i];
                temparAarrFirstnames[j] = arrFirstnames[i];
                j++;
            } else {
                removed = true;
            }
        }
        if (!removed) {
            JOptionPane.showMessageDialog(null, "Task could not be removed. Please try again");
        } else {
            arrAmounts = tempArrAmounts;
            arrFirstnames = temparAarrFirstnames;
            arrTaskIDs = tempArrTaskIDs;
            arrTasknames = tempArrNames;
            arrTaskStatus = tempArrTaskStatus;
            JOptionPane.showMessageDialog(null, "Task removed successfully.");
            taskNumber--;
        }
        return removed;
    }

    // Setters
    public void setName(String Taskname) {
        this.Taskname = Taskname;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public static void setTaskNumber() {
        taskNumber++;
    }

    public static void resetTaskNumber() {
        taskNumber = 0;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public void setDuration(double duration) {
        this.duration = duration;
        totalDuration += duration;
    }

    public void resetTotalDuration() {
        totalDuration = 0;
    }

    public void setTaskID() {
        this.taskID = createTaskID();
    }

    public void setTaskStatus(String taskStatus) {
        this.taskStatus = taskStatus;
    }

    // Method to create a task ID
    public String createTaskID() {
        // takes first two letters of task name and changes it to uppercase
        String taskFirst = Taskname.substring(0, Math.min(Taskname.length(), 2)).toUpperCase();
        // takes the last 3 letters of users name and changes it to uppercase
        String taskSecond = firstname.substring(Math.max(0, firstname.length() - 3)).toUpperCase();
        // putting variables in place with colons to meet ID requirements
        return taskFirst + ":" + taskNumber + ":" + taskSecond;
    }

    // Method to output task details as a string
    public String outputDetails() {
        String output = "Task Name:\t" + Taskname;
        output += "\nTask Number:\t" + taskNumber;
        output += "\nTask ID:\t" + taskID;
        output += "\nDeveloper:\t" + firstname;
        output += "\nTotal hours:\t" + duration;
        output += "\nTask description:\t" + description;
        output += "\n\nTask Status:\t" + taskStatus;
        return output;
    }

    // GETTERS
    public String getName() {
        return Taskname;
    }

    public String getDescription() {
        return description;
    }

    public static int getTaskNumber() {
        return taskNumber;
    }

    public String getFirstname() {
        return firstname;
    }

    public double getDuration() {
        return duration;
    }

    public double getTotalDuration() {
        return totalDuration;
    }

    public String getTaskID() {
        return taskID;
    }

    public String getTaskStatus() {
        return taskStatus;
    }

    public static void setTaskNumbers(int taskNumber) {
        Report.taskNumber = taskNumber;
    }

    public static void setTotalDurations(int totalDuration) {
        Report.totalDuration = totalDuration;
    }

    public void setTaskIDs(String taskID) {
        this.taskID = taskID;
    }

    public static void setArrFirstnames() {
        arrFirstnames = new String[20];
    }

    public static void setArrNames() {
        arrTasknames = new String[20];
    }

    public static void setArrTaskIds() {
        arrTaskIDs = new String[20];
    }

    public static void setArrAmounts() {
        arrAmounts = new double[20];
    }

}
